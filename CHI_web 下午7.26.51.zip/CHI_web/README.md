# CHI Web
## 环境安装
```bash  
npm install
```

```bash  
yarn install
```
## 运行前端
```bash  
yarn serve
```
