package com.lhd.tams.module.color.service;

import java.util.List;

public interface ColorService {

    List<String> getEffectiveList();
}
