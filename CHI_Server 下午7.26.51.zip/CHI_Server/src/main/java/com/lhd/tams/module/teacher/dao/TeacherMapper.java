package com.lhd.tams.module.teacher.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lhd.tams.module.teacher.model.data.TeacherDO;

public interface TeacherMapper extends BaseMapper<TeacherDO> {
}
