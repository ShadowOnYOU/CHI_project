package com.lhd.tams.module.color.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lhd.tams.module.color.model.data.ColorDO;

public interface ColorMapper extends BaseMapper<ColorDO> {
}
