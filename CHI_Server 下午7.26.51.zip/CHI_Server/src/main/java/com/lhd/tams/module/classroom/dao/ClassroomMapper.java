package com.lhd.tams.module.classroom.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lhd.tams.module.classroom.model.data.ClassroomDO;

public interface ClassroomMapper extends BaseMapper<ClassroomDO> {
}
