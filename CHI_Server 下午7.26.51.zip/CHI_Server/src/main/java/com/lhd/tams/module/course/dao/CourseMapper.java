package com.lhd.tams.module.course.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lhd.tams.module.course.model.data.CourseDO;

public interface CourseMapper extends BaseMapper<CourseDO> {
}
